from selenium import webdriver
from bs4 import BeautifulSoup
import csv

URL = 'https://www.xscores.com/soccer/usa/major-league-soccer/standings'
file = open("src/input.txt", 'w+')
file_csv = open("src/data.csv", 'w+', newline='')
write = csv.writer(file_csv)
driver = webdriver.Chrome(r'src\geckodriver')
driver.get(URL)
soup = BeautifulSoup(driver.page_source, 'lxml')
teamRankWrapper = soup.find_all('div', class_='team_rank_wrapper')
scrollColumn = soup.find('div', class_='scroll_column').text
file.write(scrollColumn)
file = open("src/input.txt", 'r')
list_data = []
for team_class in teamRankWrapper:
    team_name = team_class.find('div', class_='team_name ellipsis').text
    list_data.append(team_name)
    index = 0
    while True:
        word = file.readline()
        if word == '\n':
            continue
        else:
            strip_word = word.strip()
            list_data.append(strip_word)
            index = index + 1
        if index == 9:
            break
    write.writerow(list_data)
    list_data = []
